﻿
using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;

using System;
using System.Drawing.Drawing2D;
using System.Text.Json;
using System.Threading.Tasks;

namespace PowerBIEmbeddSample.Services
{
    //This is a wrapper class to run javascript code.
    public class JScriptService : IJScriptService
    {
        public async Task DisplaySearchContent(IJSRuntime js, IDispatcher dispatcher)
        {
            var jsObj = await JSFactory.GetInstance(js, dispatcher);
            await jsObj.DisplaySearchContent();
        }

        public async Task UploadDocumentCustomSetting(IJSRuntime js, IDispatcher dispatcher)
        {
            var jsObj = await JSFactory.GetInstance(js, dispatcher);

            await jsObj.UploadDocumentCustomSetting();
        }
        public async Task PropertyPageHeaderSettings(IJSRuntime js, IDispatcher dispatcher)
        {
            var jsObj = await JSFactory.GetInstance(js, dispatcher);

            await jsObj.PropertyPageHeaderSettings();
        }

        public async Task DownloadFile(IJSRuntime js, IDispatcher dispatcher, string mimeType, string base64String, string fileName)
        {
            var jsObj = await JSFactory.GetInstance(js, dispatcher);
            await jsObj.DownloadFile(mimeType, base64String, fileName);
        }

        public async Task DownloadFileArray(IJSRuntime js, IDispatcher dispatcher, string mimeType, byte[] fileContents, string fileName, bool openDocument = false)
        {
            var jsObj = await JSFactory.GetInstance(js, dispatcher);
            await jsObj.DownloadFileArray(mimeType, fileContents, fileName, openDocument);
        }

        public async Task AddingFileUploadFunctionality(IJSRuntime js, IDispatcher dispatcher)
        {
            var jsObj = await JSFactory.GetInstance(js, dispatcher);

            await jsObj.AddingFileUploadFunctionality();
        }

        public async Task ToggleDropDown(IJSRuntime js, IDispatcher dispatcher, string btnId, bool isRendered)
        {
            var jsObj = await JSFactory.GetInstance(js, dispatcher);

            await jsObj.ToggleDropDown(btnId, isRendered);
        }
        public async Task CloseSearchContentBlock(IJSRuntime js, IDispatcher dispatcher)
        {
            var jsObj = await JSFactory.GetInstance(js, dispatcher);

            await jsObj.CloseSearchContentBlock();
        }

        public async Task UserInboxDropDownClose(IJSRuntime js, IDispatcher dispatcher, string btnId)
        {
            var jsObj = await JSFactory.GetInstance(js, dispatcher);

            await jsObj.UserInboxDropDownClose(btnId);
        }

        public async Task PropertyPageDocumentFuncsDropDownClose(IJSRuntime js, IDispatcher dispatcher, string btnId)
        {
            var jsObj = await JSFactory.GetInstance(js, dispatcher);

            await jsObj.PropertyPageDocumentFuncsDropDownClose(btnId);
        }

        public async Task ClickOnDownloadPreviewingButton(IJSRuntime js, IDispatcher dispatcher)
        {
            var jsObj = await JSFactory.GetInstance(js, dispatcher);
            await jsObj.ClickOnDownloadPreviewingButton();
        }

        public async Task LeaseFilterCustomSetting(IJSRuntime js, IDispatcher dispatcher)
        {
            var jsObj = await JSFactory.GetInstance(js, dispatcher);

            await jsObj.LeaseFilterCustomSetting();
        }


        public async Task SavePdfFile(IJSRuntime js, IDispatcher dispatcher, string base64String, string mimeType, string fileName)
        {
            var jsObj = await JSFactory.GetInstance(js, dispatcher);

            await jsObj.SavePdfFile(base64String, mimeType, fileName);
        }

        public async Task<JsonElement> GetUploadedPdfFile(IJSRuntime js, IDispatcher dispatcher, string Id)
        {
            var jsObj = await JSFactory.GetInstance(js, dispatcher);
            return await jsObj.GetUploadedPdfFile(Id);
        }
        public async Task ClickOnPreviewedDocumentSearchBtn(IJSRuntime js, IDispatcher dispatcher)
        {
            var jsObj = await JSFactory.GetInstance(js, dispatcher);

            await jsObj.ClickOnPreviewedDocumentSearchBtn();
        }
        public async Task LeaseFilterResetCheckbox(IJSRuntime js, IDispatcher dispatcher, string elementName)
        {
            var jsObj = await JSFactory.GetInstance(js, dispatcher);

            await jsObj.LeaseFilterResetCheckbox(elementName);
        }

        public async Task ZoomInPage(IJSRuntime js, IDispatcher dispatcher, string eleId)
        {
            var jsObj = await JSFactory.GetInstance(js, dispatcher);
            await jsObj.ZoomInPage(eleId);
        }

        public async Task ZoomOutPage(IJSRuntime js, IDispatcher dispatcher, string eleId)
        {
            var jsObj = await JSFactory.GetInstance(js, dispatcher);
            await jsObj.ZoomOutPage(eleId);
        }

        public async Task EditDocumentName(IJSRuntime js, IDispatcher dispatcher)
        {
            var jsObj = await JSFactory.GetInstance(js, dispatcher);

            await jsObj.EditDocumentName();
        }

        public async Task EditDocumentRecordClass(IJSRuntime js, IDispatcher dispatcher, string documentName, string changeType)
        {
            var jsObj = await JSFactory.GetInstance(js, dispatcher);

            await jsObj.EditDocumentRecordClass(documentName, changeType);
        }

        public async Task DisplayCustomDialogueById(IJSRuntime js, IDispatcher dispatcher, string eleId)
        {
            var jsObj = await JSFactory.GetInstance(js, dispatcher);
            await jsObj.DisplayCustomDialogueById(eleId);
        }

        public async Task HideCustomDialogueById(IJSRuntime js, IDispatcher dispatcher, string eleId)
        {
            var jsObj = await JSFactory.GetInstance(js, dispatcher);
            await jsObj.HideCustomDialogueById(eleId);
        }

        public async Task SetDocumentViewerPageStyle(IJSRuntime js, IDispatcher dispatcher, bool sidebarStatus)
        {
            var jsObj = await JSFactory.GetInstance(js, dispatcher);
            await jsObj.SetDocumentViewerPageStyle(sidebarStatus);
        }

        public async Task ChangeDocumentTypeDropdown(IJSRuntime js, IDispatcher dispatcher, string selectedFolder, bool documentExists)
        {
            var jsObj = await JSFactory.GetInstance(js, dispatcher);

            await jsObj.ChangeDocumentTypeDropdown(selectedFolder, documentExists);
        }
    }
}
