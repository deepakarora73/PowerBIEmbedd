﻿
using Microsoft.Identity.Client;
using System;
using System.Linq;
using System.Threading.Tasks;


using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;

namespace PowerBIEmbeddSample.Services.Client.Services
{
    public class AuthenticationHelper
    {
        private const string clientId = "c4c71b44-3319-4f45-be91-99a19088c7d8";
        private const string tenantId = "23dc5d9e-d109-457d-95f5-fb775e4cbf8d";
        //private const string redirectUri = "YOUR_REDIRECT_URI";

        public static async Task<string> GetAccessTokenAsync()
        {
            var clientApp = PublicClientApplicationBuilder
                .Create(clientId)
                .WithAuthority(new Uri($"https://login.microsoftonline.com/{tenantId}"))
                //.WithRedirectUri(redirectUri)
                .Build();

            var scopes = new[] { "\"https://analysis.windows.net/powerbi/api/Report.Read.All https://analysis.windows.net/powerbi/api/Dashboard.Read.All https://analysis.windows.net/powerbi/api/Workspace.Read.All" };

            var accounts = await clientApp.GetAccountsAsync();

            try
            {
                var authResult = await clientApp.AcquireTokenSilent(scopes, accounts.FirstOrDefault())
                    .ExecuteAsync();

                return authResult.AccessToken;
            }
            catch (MsalUiRequiredException)
            {
                throw new Exception("Interactive authentication is required.");
            }
        }
    }

    public static class Interop
    {
        internal static ValueTask<object> CreateReport(
            IJSRuntime jsRuntime,
            ElementReference reportContainer,
            string accessToken,
            string embedUrl,
            string embedReportId)
        {
            return jsRuntime.InvokeAsync<object>(
                "ShowMyPowerBI.showReport",
                reportContainer, accessToken, embedUrl,
                embedReportId);
        }
    }
}
